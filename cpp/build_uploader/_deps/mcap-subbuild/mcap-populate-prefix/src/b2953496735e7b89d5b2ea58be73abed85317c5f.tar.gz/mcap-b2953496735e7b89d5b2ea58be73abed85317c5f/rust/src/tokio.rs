//! Read MCAP data from a stream asynchronously
pub mod linear_reader;

pub use linear_reader::{LinearReader, LinearReaderOptions};
