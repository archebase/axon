package main

import "github.com/foxglove/mcap/go/cli/mcap/cmd"

func main() {
	cmd.Execute()
}
