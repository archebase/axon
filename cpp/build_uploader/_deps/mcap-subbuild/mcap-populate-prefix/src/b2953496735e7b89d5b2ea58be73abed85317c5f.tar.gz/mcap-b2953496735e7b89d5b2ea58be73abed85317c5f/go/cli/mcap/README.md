## MCAP CLI

A command line tool to work with MCAP files. See https://mcap.dev/guides/cli for documentation.

## Build from source

You can build the CLI tool from source by running `make build` in the same directory as this README.

```
$ make build
```

The binary will be built to a `bin` folder in the same directory.
