******************************
Working with Protobuf Messages
******************************

Reader Example
--------------
.. literalinclude:: ../examples/protobuf/reader.py

Writer Example
--------------
.. literalinclude:: ../examples/protobuf/writer.py
